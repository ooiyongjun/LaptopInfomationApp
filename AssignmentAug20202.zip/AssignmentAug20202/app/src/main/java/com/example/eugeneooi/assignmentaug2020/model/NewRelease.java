package com.example.eugeneooi.assignmentaug2020.model;

public class NewRelease {

    private String name;
    private String imageUrl;
    private String brand;
    private String price;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }



    public NewRelease(String name, String imageUrl, String brand, String price) {
        this.name = name;
        this.imageUrl = imageUrl;
        this.brand = brand;
        this.price = price;
    }
}
