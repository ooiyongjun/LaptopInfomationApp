package com.example.eugeneooi.assignmentaug2020.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.eugeneooi.assignmentaug2020.ProductDetail;
import com.example.eugeneooi.assignmentaug2020.R;
import com.example.eugeneooi.assignmentaug2020.model.MostVisited;

import java.util.List;

public class MostVisitedRecyclerAdapter extends RecyclerView.Adapter<MostVisitedRecyclerAdapter.MostVisitedViewHolder>{

    private Context context;
    private List<MostVisited> mMostVisitedList;

    public MostVisitedRecyclerAdapter(Context context, List<MostVisited> mostVisitedList) {
        this.context = context;
        this.mMostVisitedList = mostVisitedList;
    }


    @Override
    public MostVisitedViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view;
        LayoutInflater inflater = LayoutInflater.from(context);
        view = inflater.inflate(R.layout.most_visited_recycler_item , viewGroup, false);
        final MostVisitedViewHolder viewHolder = new MostVisitedViewHolder(view);
        return viewHolder;

    }

    @Override
    public void onBindViewHolder(MostVisitedRecyclerAdapter.MostVisitedViewHolder mostVisitedViewHolder, final int postion) {

        mostVisitedViewHolder.itemName.setText(mMostVisitedList.get(postion).getName());
        mostVisitedViewHolder.price.setText(mMostVisitedList.get(postion).getPrice());
        mostVisitedViewHolder.rating.setText(mMostVisitedList.get(postion).getRating());
        mostVisitedViewHolder.type.setText(mMostVisitedList.get(postion).getType());

        // Glide.with(context).load(mNewReleaseList.get(i).getImageUrl()).into(mostVisitedViewHolder.itemImage);

        mostVisitedViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(context, ProductDetail.class);
                i.putExtra("name",mMostVisitedList.get(postion).getName());
                i.putExtra("rating",mMostVisitedList.get(postion).getRating());
                i.putExtra("price",mMostVisitedList.get(postion).getPrice());
                context.startActivity(i);

            }
        });
    }

    @Override
    public int getItemCount() {
        return mMostVisitedList.size();
    }

    public static class MostVisitedViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        ImageView itemImage;
        TextView price, rating, itemName, type;
        LinearLayout Linear_most_visited;
        public MostVisitedViewHolder(View itemView) {
            super(itemView);

            Linear_most_visited = itemView.findViewById(R.id.most_visited);
            itemImage = itemView.findViewById(R.id.laptopView);
            price = itemView.findViewById(R.id.price);
            rating = itemView.findViewById(R.id.rating);
            itemName = itemView.findViewById(R.id.name);
            type = itemView.findViewById(R.id.type);

        }

        @Override
        public void onClick(View v) {

        }
    }


}

