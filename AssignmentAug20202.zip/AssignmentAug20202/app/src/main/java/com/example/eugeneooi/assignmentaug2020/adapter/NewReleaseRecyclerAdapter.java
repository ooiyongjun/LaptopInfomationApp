package com.example.eugeneooi.assignmentaug2020.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

//import com.bumptech.glide.Glide;
import com.example.eugeneooi.assignmentaug2020.ProductDetail;
import com.example.eugeneooi.assignmentaug2020.R;
import com.example.eugeneooi.assignmentaug2020.model.NewRelease;

import java.util.List;

public class NewReleaseRecyclerAdapter extends RecyclerView.Adapter<NewReleaseRecyclerAdapter.NewReleaseViewHolder>{

    private Context context;
    private List<NewRelease> mNewReleaseList;

    public NewReleaseRecyclerAdapter(Context context, List<NewRelease> newReleaseList) {
        this.context = context;
        this.mNewReleaseList = newReleaseList;
    }



    @Override
    public NewReleaseViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view;
        LayoutInflater inflater = LayoutInflater.from(context);
        view = inflater.inflate(R.layout.new_release_recycler_item , viewGroup, false);
        final NewReleaseViewHolder viewHolder = new NewReleaseViewHolder(view);
        return viewHolder;

    }

    @Override
    public void onBindViewHolder(final NewReleaseViewHolder newReleaseViewHolder, final int postion) {

        newReleaseViewHolder.itemName.setText(mNewReleaseList.get(postion).getName());
        newReleaseViewHolder.price.setText(mNewReleaseList.get(postion).getPrice());
        newReleaseViewHolder.brand.setText(mNewReleaseList.get(postion).getBrand());
        // Glide.with(context).load(mNewReleaseList.get(i).getImageUrl()).into(newReleaseViewHolder.itemImage);

        newReleaseViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(context, ProductDetail.class);
                i.putExtra("name",mNewReleaseList.get(postion).getName());
                i.putExtra("price",mNewReleaseList.get(postion).getPrice());
                context.startActivity(i);

            }
        });

    }

    @Override
    public int getItemCount() {
        return mNewReleaseList.size();
    }

    public static class NewReleaseViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        ImageView itemImage;
        TextView price, brand, itemName;
        LinearLayout Linear_new_release;
        public NewReleaseViewHolder(View itemView) {
            super(itemView);

            Linear_new_release = itemView.findViewById(R.id.new_release);
            itemImage = itemView.findViewById(R.id.imageView);
            price = itemView.findViewById(R.id.price);
            brand = itemView.findViewById(R.id.brand);
            itemName = itemView.findViewById(R.id.laptop_name);
            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View v) {

        }
    }
}

