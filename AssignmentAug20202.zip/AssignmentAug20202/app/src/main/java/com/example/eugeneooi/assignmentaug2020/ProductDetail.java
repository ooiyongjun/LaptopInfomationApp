package com.example.eugeneooi.assignmentaug2020;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class ProductDetail extends AppCompatActivity {

    TextView productName, productPrice, productRating;
    ImageView backButton, shareButton;
    Button wishlistBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_detail);

        Intent i = getIntent();

        String name = i.getStringExtra("name");
        String price = i.getStringExtra("price");
        String rating = i.getStringExtra("rating");

        productName = findViewById(R.id.detail_name);
        productPrice = findViewById(R.id.price);
        productRating = findViewById(R.id.rating);
        backButton = findViewById(R.id.back_button);
        wishlistBtn = findViewById(R.id.bn_wishlist);
        shareButton = findViewById(R.id.share);


        productName.setText(name);
        productRating.setText(rating);
        productPrice.setText(price);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(ProductDetail.this, MainActivity.class);
                startActivity(i);
                finish();
            }
        });
        wishlistBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(ProductDetail.this,"Laptop is added to wishlist!", Toast.LENGTH_SHORT).show();
            }
        });
        shareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(ProductDetail.this,"Thank you for sharing!", Toast.LENGTH_SHORT).show();

            }
        });
    }
}
