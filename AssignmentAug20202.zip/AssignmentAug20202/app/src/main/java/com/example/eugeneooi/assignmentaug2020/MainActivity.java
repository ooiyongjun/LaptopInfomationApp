package com.example.eugeneooi.assignmentaug2020;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.example.eugeneooi.assignmentaug2020.adapter.MostVisitedRecyclerAdapter;
import com.example.eugeneooi.assignmentaug2020.adapter.NewReleaseRecyclerAdapter;
import com.example.eugeneooi.assignmentaug2020.model.MostVisited;
import com.example.eugeneooi.assignmentaug2020.model.NewRelease;


import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView mRecyclerView;
    private RecyclerView mostVisitedRecycerView;
    NewReleaseRecyclerAdapter mNewReleaseRecyclerAdapter;
    MostVisitedRecyclerAdapter mMostVisitedRecyclerAdapter;
    List<NewRelease> mNewReleaseList;
    List<MostVisited> mMostVisitedList;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        mRecyclerView = findViewById(R.id.recyclerView);
        mostVisitedRecycerView = findViewById(R.id.most_visited_recycler);

        mNewReleaseList = new ArrayList<>();
        mMostVisitedList = new ArrayList<>();

        NewRelease product1 = new NewRelease("ASUS ROG G14","","ASUS","RM 4450");
        NewRelease product2 = new NewRelease("DELL XPS 15","","DELL","RM 7999");
        NewRelease product3 = new NewRelease("ACER Swift 3","https://firebasestorage.googleapis.com/v0/b/androidapplaptop.appspot.com/o/laptopimage%2Facer%20swift3.png?alt=media&token=f7b4f0cf-8c11-497a-a51f-38cc52138e2f","ACER","RM 3399");
        NewRelease product4 = new NewRelease("Lenovo Y740","","Lenovo","RM 7035");
        NewRelease product5 = new NewRelease("LG Gram 17","","LG","RM 5078");

        //dell https://firebasestorage.googleapis.com/v0/b/androidapplaptop.appspot.com/o/laptopimage%2Fdell%20xps%2015.png?alt=media&token=34ffd731-13ea-4a8e-a2be-b984211f1c5b
        //asus https://firebasestorage.googleapis.com/v0/b/androidapplaptop.appspot.com/o/laptopimage%2Fg14%20asus.png?alt=media&token=6e7a005e-fa7c-4f9c-b091-d25bc7a0cfa4
        //acer https://firebasestorage.googleapis.com/v0/b/androidapplaptop.appspot.com/o/laptopimage%2Facer%20swift3.png?alt=media&token=f7b4f0cf-8c11-497a-a51f-38cc52138e2f
        //lenovo https://firebasestorage.googleapis.com/v0/b/androidapplaptop.appspot.com/o/laptopimage%2Flenovo%20y740.png?alt=media&token=664d4385-0ced-41c9-b396-fe37ff8a76bb
        //lg https://firebasestorage.googleapis.com/v0/b/androidapplaptop.appspot.com/o/laptopimage%2Flg%20gram.png?alt=media&token=936dbab1-956d-4ce8-b11b-bbeeef7b327a
        mNewReleaseList.add(product1);
        mNewReleaseList.add(product2);
        mNewReleaseList.add(product3);
        mNewReleaseList.add(product4);
        mNewReleaseList.add(product5);

        MostVisited mostVisited1 = new MostVisited("Dell XPS 15","Business","","RM 7999","4.8");
        MostVisited mostVisited2 = new MostVisited("ASUS ROG G14","Gaming","","RM 4450","4.5");
        MostVisited mostVisited3 = new MostVisited("LG Gram 17","Business","","RM 5078","4.0");
        MostVisited mostVisited4 = new MostVisited("ACER Swift 3","Business","","RM 3399","3.8");
        MostVisited mostVisited5 = new MostVisited("Lenovo Y740","Gaming","","RM 7035","3.9");

        mMostVisitedList.add(mostVisited1);
        mMostVisitedList.add(mostVisited2);
        mMostVisitedList.add(mostVisited3);
        mMostVisitedList.add(mostVisited4);
        mMostVisitedList.add(mostVisited5);

        mNewReleaseRecyclerAdapter = new NewReleaseRecyclerAdapter(this, mNewReleaseList);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL,  false));
        mRecyclerView.setAdapter(mNewReleaseRecyclerAdapter);
        mNewReleaseRecyclerAdapter.notifyDataSetChanged();

        mMostVisitedRecyclerAdapter = new MostVisitedRecyclerAdapter(this, mMostVisitedList);
        mostVisitedRecycerView.setHasFixedSize(true);
        mostVisitedRecycerView.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        mostVisitedRecycerView.setAdapter(mMostVisitedRecyclerAdapter);
        mMostVisitedRecyclerAdapter.notifyDataSetChanged();
    }
}

